<?php
session_start();

if(isset($_SESSION["uname"]) && time() - $_SESSION["LAT"] <= 10 )
{
$_SESSION["LAT"] = time();
echo "Hello, ".$_SESSION["uname"]."<br />";

if($_SESSION["utype"] == "admin")
{
	echo "<a href=view.php>View Data</a><br />";
	echo "<a href=add.php>Add Data</a><br />";		
}
else if($_SESSION["utype"] == "user")
{
	echo "<a href=view.php>View Data</a><br />";
}

echo "<a href=logout.php>Logout</a><br />";
}
else
{
	header("Location:logout.php");	
}

?>