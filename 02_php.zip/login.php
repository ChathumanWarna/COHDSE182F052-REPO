<html>
<head><title>Login</title></head>
<body>
<form name="frmLogin" method="post" action="#">
Username:<input type="text" name="txtUN" /><br />
Password:<input type="password" name="txtPW" /><br />
<input type="submit" name="btnLogin" value="Login" />
</form>
</body>
</html>
<?php
//accept data from the HTML form
if(isset($_POST["txtUN"]))
{
	$un = $_POST["txtUN"];
	$pw = $_POST["txtPW"];
	
	//Connect with mysql to load tbluser data
	$con = mysqli_connect("localhost","root","");
	mysqli_select_db($con,"studentdb");
	
	$sql = "Select * from tbluser";
	$result = mysqli_query($con,$sql);
	
	$flag = 0;
	while($row = mysqli_fetch_array($result))
	{
		if($un == $row[1] && $pw == $row[2])
		{
			$flag = 1;	
		}
	}
	
	if($flag == 1)
	{
		session_start();
		$_SESSION["uname"] = $un;
		$_SESSION["LAT"] = time(10);
		//redirect user to welcome.php
		header("Location:welcome.php");	
	}
	else
	{
		echo "Invalid username or password";	
	}
		mysqli_close($con);
	
}
?>